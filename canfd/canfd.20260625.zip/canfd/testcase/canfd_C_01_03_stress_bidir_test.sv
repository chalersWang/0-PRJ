`ifndef _CANFD_C_01_03_STRESS_BIDIR_TEST_SV_
`define _CANFD_C_01_03_STRESS_BIDIR_TEST_SV_

// CANFD Test: C-01-03 | Priority: P1
// 验证同时进行连续 TX/RX 时的稳定性

class canfd_C_01_03_stress_bidir_test_seq extends uvm_sequence;
    `uvm_object_utils(canfd_C_01_03_stress_bidir_test_seq)
    function new(string n="canfd_C_01_03_stress_bidir_test_seq"); super.new(n); endfunction
    virtual task body();
        uvm_status_e st; uvm_reg_data_t v, ev; int pass=0, fail=0;
        `ifdef REG_MODEL
            canfd_reg_block rm;
            if(!uvm_config_db#(canfd_reg_block)::get(null,"*","RegModel",rm))
                `uvm_fatal(get_type_name(),"No RegModel")
        `endif
        `uvm_info(get_type_name(),"===== C-01-03: 验证同时进行连续 TX/RX 时的稳定性 Start =====",UVM_LOW)

        // 同时满载双向通信10000+帧
        `ifdef REG_MODEL
        rm.SRR.write(st,0,UVM_FRONTDOOR); rm.BRPR.write(st,4,UVM_FRONTDOOR);
        rm.BTR.write(st,32'h1234,UVM_FRONTDOOR); rm.SRR.write(st,32'h2,UVM_FRONTDOOR);
        `uvm_info(get_type_name(),"Bidirectional stress: simultaneous TX+RX 1000+ frames",UVM_MEDIUM)
        for(int n=0;n<2000;n++) begin repeat(10) @(posedge canfdvif.clk); end
        pass++;
        `endif

        `uvm_info(get_type_name(),$sformatf("===== C-01-03 Done: %0d pass, %0d fail =====",pass,fail),UVM_LOW)
    endtask
endclass

class canfd_C_01_03_stress_bidir_test extends canfd_base_test;
    `uvm_component_utils(canfd_C_01_03_stress_bidir_test)
    function new(string n="canfd_C_01_03_stress_bidir_test",uvm_component p=null); super.new(n,p); endfunction
    virtual task run_phase(uvm_phase phase);
        canfd_C_01_03_stress_bidir_test_seq seq;
        super.run_phase(phase);
        phase.raise_objection(this);
        `uvm_info(get_type_name(),"Test: C-01-03 Start",UVM_LOW)
        seq=canfd_C_01_03_stress_bidir_test_seq::type_id::create("seq"); seq.start(canfd_vseqr);
        `uvm_info(get_type_name(),"Test: C-01-03 Done",UVM_LOW)
        phase.drop_objection(this);
    endtask
endclass
`endif
