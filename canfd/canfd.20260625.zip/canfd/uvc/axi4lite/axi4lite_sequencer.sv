`ifndef _AXI4LITE_SEQUENCER_SV_
`define _AXI4LITE_SEQUENCER_SV_

class axi4lite_sequencer extends uvm_sequencer #(axi4lite_trans);

    `uvm_component_utils(axi4lite_sequencer)

    function new(string name="axi4lite_sequencer", uvm_component parent=null);
        super.new(name, parent);
    endfunction

endclass

`endif
